
let handler = async (m, { conn }) => {

m.reply(`
*ʜᴏʟᴀ ᴇsᴛɪᴍᴀᴅᴏs ᴜsᴜᴀʀɪᴏs 👋🏻,  ᴛᴇ ɪɴᴠɪᴛᴏ ᴀ ᴜɴɪʀᴛᴇ ᴀ ʟᴏs ɢʀᴜᴘᴏs ᴏғɪᴄɪᴀʟᴇs ᴅᴇ ʟᴀs ғᴀᴍɪʟᴀs ᴛʜᴇ ʟᴏʟɪʙᴏᴛ-ᴍᴅ ʏ ɴᴏᴠᴀʙᴏᴛ-ᴍᴅ, ᴘᴀʀᴀ ᴄᴏɴᴠɪᴠɪʀ ᴄᴏɴ ʟᴀ ᴄᴏᴍᴜɴɪᴅᴀᴅ :ᴠ*

*➤ ɢʀᴜᴘᴏs ᴏғɪᴄɪᴀʟᴇs ᴅᴇʟ ʙᴏᴛ:*
1) https://chat.whatsapp.com/LZFE2MHvEkY7b69TmAGmHR

2) https://chat.whatsapp.com/IIteN3dd6rG87b2liETl2o

ɢʀᴜᴘᴏ ᴅᴇʟ ᴄᴏʟᴀʙᴏʀᴀᴄɪᴏɴ ɢᴀᴛᴀʙᴏᴛ-ᴍᴅ ʏ ʟᴏʟɪʙᴏᴛ-ᴍᴅ 
https://chat.whatsapp.com/CcJKHrxGBWAAH3PiBL07JS

ɢʀᴜᴘᴏ ᴅᴇʟ ᴄᴏʟ ² (ᴀǫᴜɪ sᴇ ᴘᴇʀᴍɪᴛᴇ ᴛᴏᴅᴏ ʟᴏs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇʟ ʙᴏᴛ)
https://chat.whatsapp.com/FfiQUYDDtaG9bwaI7UKMAR

ɪɴғᴏᴍᴀʀᴛᴇ sᴏʙʀᴇ ʟᴀs ɴᴜᴇᴠᴀs ᴀᴄᴛᴜᴀʟɪᴢᴀᴄɪᴏɴᴇs ᴅᴇʟ ʙᴏᴛ ᴀǫᴜɪ 
https://chat.whatsapp.com/JESaesjOEcB6wnGX0QYT9o

ɢʀᴜᴘᴏ ᴅᴇʟ ᴀʏᴜᴅᴀ sᴏʙʀᴇ ᴇʟ ʙᴏᴛ 
https://chat.whatsapp.com/FRkr7jJHSJA5OjVtE64dDs

┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈
ɢʀᴜᴘᴏs ᴅᴇʟ ᴀᴍɪsᴛᴀᴅᴇs ᴅᴏɴᴅᴇ ᴇsᴛᴀ ᴇʟ ʙᴏᴛ

*ஓீ͜ঔৣ͡🍒STICKER/𝑩Ø𝑻🔥ঔৣ͡ஓ*
https://chat.whatsapp.com/DCJclB8oBAPIAoleUtNEaN

*꧁⁣𓆩Aᴹᴵᴳᴼˢ Cᴴᴬᵀˢ Y Aᴾᴼᴿᵀᴱ*
https://chat.whatsapp.com/JZaD3sfNoVW4JvaoQ4uVwF

*⇶⃤꙰𝑬𝒏𝒍𝒂𝒄𝒆 𝒍𝒐𝒍𝒊𝒃𝒐𝒕ꦿ⃟⃢*
https://chat.whatsapp.com/DsFPvTLFDQaBroutCnD2DO
ᴀǫᴜɪ ᴘᴜᴇᴅᴇ ᴍᴀɴᴅᴀ ᴛᴜ ᴇɴʟᴀᴄᴇ ʏ ᴛᴀᴍʙɪᴇɴ sɪ ǫᴜɪᴇʀᴇ ᴜɴ ʙᴏᴛ ᴘᴀʀᴀ ᴛᴜ ɢʀᴜᴘᴏ ᴘᴏɴᴇʀ ᴇʟ ᴄᴏᴍᴀɴᴅᴏ .ᴊᴏɪɴ (ᴍᴀs ᴇɴʟᴀᴄᴇ)

*꧁⃢⃟҉💫🌺ঔঔ𝔼ℕ𝕃𝔸ℂ𝔼𝕊 𝕃𝔸 𝕁𝔼𝔽𝔸✨*
https://chat.whatsapp.com/JegOp8NUSMd0vn75s4hkaj
┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈

sɪ ǫᴜɪᴇʀᴇs ǫᴜᴇ ᴛᴜ ɢʀᴜᴘᴏ ᴀᴘᴀʀᴇᴢᴄᴀɴ ᴀᴄᴀ ʜᴀʙʟᴀ ᴄᴏɴ ᴇʟ ᴀᴅᴍɪɴ ᴏғᴄ ᴅᴇʟ ʙᴏᴛ`)

}
handler.help = ['support']
handler.tags = ['main']
handler.command = ['grupos', 'groupnova', 'dxgp', 'dygp', 'gpdynova', 'support'] 
handler.register = true

export default handler
